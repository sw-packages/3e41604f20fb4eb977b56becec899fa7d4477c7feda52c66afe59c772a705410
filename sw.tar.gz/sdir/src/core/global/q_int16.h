#include <qglobal.h>
